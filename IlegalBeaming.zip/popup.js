document.addEventListener('DOMContentLoaded', function() {

    // ── DOM ──
    const navBtns           = document.querySelectorAll('.nav-btn');
    const tabContents       = document.querySelectorAll('.tab-content');
    const loginForm         = document.getElementById('loginForm');
    const accessForm        = document.getElementById('accessForm');
    const backBtn           = document.getElementById('backBtn');
    const getCookieBtn      = document.getElementById('getCookieBtn');
    const profileView       = document.getElementById('profileView');
    const loginCard         = document.querySelector('#loginTab .card');
    const accountsList      = document.getElementById('accountsList');
    const accountsCountBadge = document.getElementById('accountsCountBadge');
    const clearAccountsBtn  = document.getElementById('clearAccountsBtn');

    let currentCookie = '';


    // ── NAV ──
    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            switchTab(btn.getAttribute('data-tab'));
        });
    });

    function switchTab(tabName) {
        tabContents.forEach(t => t.classList.remove('active'));
        navBtns.forEach(b => b.classList.remove('active'));
        document.getElementById(tabName + 'Tab').classList.add('active');
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        if (tabName !== 'login') {
            profileView.style.display = 'none';
            loginCard.style.display = 'block';
        }

        if (tabName === 'accounts') {
            renderAccounts();
        }

        if (tabName === 'robux') {
            startRobuxTracker();
        }

        if (tabName === 'dashboard') {
            renderDashboard();
        }
    }

    // ── ALERTS ──
    function showAlert(message, type, alertId) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type}`;
        const icon = type === 'success' ? 'check-circle'
                   : type === 'error'   ? 'exclamation-circle'
                   : type === 'warning' ? 'exclamation-triangle'
                   : 'info-circle';
        alertDiv.innerHTML = `<div class="alert-main"><i class="fas fa-${icon}"></i> ${message}</div>`;
        const alertContainer = document.getElementById(alertId);
        alertContainer.innerHTML = '';
        alertContainer.appendChild(alertDiv);
    }

    function showLogin() {
        loginCard.style.display = 'block';
        profileView.style.display = 'none';
        document.getElementById('login-alert').innerHTML = '';
        document.getElementById('cookie').value = '';
    }

    // ── AVATAR ──
    function getAvatarUrl(userId) {
        return fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=420x420&format=Png`)
            .then(r => r.json())
            .then(json => {
                if (json.data && json.data.length && json.data[0].imageUrl) return json.data[0].imageUrl;
                return 'https://tr.rbxcdn.com/f401f3ae246e8cec456b69134f83ea67/420/420/AvatarHeadshot/Png';
            })
            .catch(() => 'https://tr.rbxcdn.com/f401f3ae246e8cec456b69134f83ea67/420/420/AvatarHeadshot/Png');
    }

    // ── ROBUX BALANCE ──
    async function getRobux(userId) {
        try {
            const res = await fetch(`https://economy.roblox.com/v1/users/${userId}/currency`, { credentials: 'include' });
            const data = await res.json();
            return data.robux !== undefined ? String(data.robux) : '0';
        } catch (e) { return '0'; }
    }

    // ── USER PROFILE ──
    function getUserProfile(id) {
        return fetch(`https://users.roblox.com/v1/users/${id}`)
            .then(r => r.json())
            .catch(() => ({}));
    }

    // ── SHOW USER INFO + SAVE ACCOUNT ──
    async function showUserInfo(user) {
        const profile   = await getUserProfile(user.id);
        const avatarUrl = await getAvatarUrl(user.id);
        const robux     = await getRobux(user.id);

        const idStr    = user.id   ? String(user.id)   : '';
        const nameStr  = user.name ? String(user.name) : '';
        const createdRaw  = profile && profile.created ? profile.created : '';
        const createdText = createdRaw ? new Date(createdRaw).toLocaleDateString('pt-BR') : 'Não fornecida';
        const daysSince   = createdRaw
            ? Math.floor((Date.now() - new Date(createdRaw).getTime()) / (1000 * 60 * 60 * 24))
            : 'N/A';

        document.getElementById('userAvatar').src           = avatarUrl;
        document.getElementById('userName').textContent     = nameStr;
        document.getElementById('userId').textContent       = idStr;
        document.getElementById('userCreated').textContent  = createdText;
        document.getElementById('daysSince').textContent    = daysSince;
        document.getElementById('userRobux').textContent    = robux;
        document.getElementById('userSpent').textContent    = 'Analisando...';

        loginCard.style.display   = 'none';
        profileView.style.display = 'block';

        // Save basic account info first
        const accountData = {
            id: idStr,
            name: nameStr,
            avatarUrl,
            robux,
            createdText,
            loginDate: new Date().toLocaleDateString('pt-BR'),
            totalSpent: null,
            topItems: null
        };
        saveAccount(accountData);

        // Fetch spending data in background
        fetchRobuxSpendingForAccount(idStr, user.id);

        setTimeout(() => {
            chrome.tabs.create({ url: 'https://www.roblox.com/my/account#!/info' });
        }, 2000);
    }

    // ──────────────────────────────────────────
    //  ROBUX SPENDING ANALYSIS (background)
    // ──────────────────────────────────────────

    async function fetchRobuxSpendingForAccount(accountIdStr, numericUserId) {
        try {
            const transactions = await robuxFetchAllTransactions(numericUserId, () => {});
            const total = transactions.reduce((sum, t) => sum + t.amount, 0);
            const sorted = [...transactions].sort((a, b) => b.amount - a.amount);
            const topItems = sorted.slice(0, 5).map(t => ({ name: t.name, amount: t.amount }));

            // Also fetch limiteds for RAP value
            let totalRAP = 0;
            try {
                const limiteds = await robuxFetchAllLimiteds(numericUserId, () => {});
                totalRAP = limiteds.reduce((sum, l) => sum + (l.rap || 0), 0);
            } catch (e) { totalRAP = 0; }

            updateAccountSpending(accountIdStr, total, topItems, totalRAP);

            const spentEl = document.getElementById('userSpent');
            if (spentEl) spentEl.textContent = total.toLocaleString('pt-BR') + ' Robux';
        } catch (e) {
            const spentEl = document.getElementById('userSpent');
            if (spentEl) spentEl.textContent = 'Indisponível';
        }
    }

    function updateAccountSpending(accountIdStr, total, topItems, totalRAP) {
        loadAccounts(function(accounts) {
            const idx = accounts.findIndex(a => a.id === accountIdStr);
            if (idx !== -1) {
                accounts[idx].totalSpent = total;
                accounts[idx].topItems   = topItems;
                if (totalRAP !== undefined) accounts[idx].totalRAP = totalRAP;
                chrome.storage.local.set({ savedAccounts: accounts }, function() {
                    const accountsTab = document.getElementById('accountsTab');
                    if (accountsTab && accountsTab.classList.contains('active')) {
                        renderAccounts();
                    }
                    const dashTab = document.getElementById('dashboardTab');
                    if (dashTab && dashTab.classList.contains('active')) {
                        renderDashboard();
                    }
                });
            }
        });
    }

    // ──────────────────────────────────────────
    //  ACCOUNTS STORAGE
    // ──────────────────────────────────────────

    function loadAccounts(cb) {
        chrome.storage.local.get(['savedAccounts'], function(result) {
            cb(result.savedAccounts || []);
        });
    }

    function saveAccount(account) {
        loadAccounts(function(accounts) {
            const idx = accounts.findIndex(a => a.id === account.id);
            if (idx !== -1) {
                // Preserve spending data if already analyzed
                const existing = accounts[idx];
                accounts[idx] = {
                    ...account,
                    totalSpent: existing.totalSpent !== undefined ? existing.totalSpent : account.totalSpent,
                    topItems:   existing.topItems   !== undefined ? existing.topItems   : account.topItems
                };
            } else {
                accounts.unshift(account);
            }
            if (accounts.length > 50) accounts = accounts.slice(0, 50);
            chrome.storage.local.set({ savedAccounts: accounts });
        });
    }

    function removeAccount(accountId) {
        loadAccounts(function(accounts) {
            const updated = accounts.filter(a => a.id !== accountId);
            chrome.storage.local.set({ savedAccounts: updated }, function() {
                renderAccounts();
            });
        });
    }

    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function renderAccounts() {
        loadAccounts(function(accounts) {
            accountsCountBadge.textContent = accounts.length === 1 ? '1 conta' : `${accounts.length} contas`;

            if (accounts.length === 0) {
                accountsList.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon"><i class="fas fa-user-circle"></i></div>
                        <div class="empty-state-title">Nenhuma conta salva</div>
                        <div class="empty-state-text">Faça login com um cookie para registrar uma conta aqui.</div>
                    </div>`;
                clearAccountsBtn.style.display = 'none';
                return;
            }

            clearAccountsBtn.style.display = 'flex';
            accountsList.innerHTML = '';

            accounts.forEach(function(acc) {
                const item = document.createElement('div');
                item.className = 'account-item';

                // Robux spent display
                let spentHtml = '';
                if (acc.totalSpent === null || acc.totalSpent === undefined) {
                    spentHtml = `<div class="account-spent-loading"><i class="fas fa-spinner fa-spin" style="font-size:9px;"></i> Analisando gastos...</div>`;
                } else {
                    spentHtml = `<div class="account-spent"><i class="fas fa-arrow-down" style="font-size:9px;"></i> Gasto: ${acc.totalSpent.toLocaleString('pt-BR')} Robux</div>`;
                }

                // Top items panel
                let topItemsHtml = '';
                if (acc.topItems && acc.topItems.length > 0) {
                    const rows = acc.topItems.map((it, i) => {
                        const rankCls = i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : '';
                        return `
                            <div class="top-item-row">
                                <span class="top-item-rank ${rankCls}">#${i + 1}</span>
                                <span class="top-item-name" title="${escHtml(it.name)}">${escHtml(it.name)}</span>
                                <span class="top-item-amount">
                                    <svg class="top-item-robux-icon" viewBox="0 0 16 16" fill="none"><path d="M4 12L6 4H12L10 12H4Z" fill="#22c55e"/></svg>
                                    ${it.amount.toLocaleString('pt-BR')}
                                </span>
                            </div>`;
                    }).join('');
                    topItemsHtml = `
                        <div class="account-top-items" id="top-items-${acc.id}">
                            <div class="top-items-title">🏆 Top Itens mais caros</div>
                            ${rows}
                        </div>`;
                } else if (acc.topItems !== null && acc.topItems !== undefined && acc.topItems.length === 0) {
                    topItemsHtml = `
                        <div class="account-top-items" id="top-items-${acc.id}">
                            <div class="top-items-analyzing" style="color:var(--text-sec);">Nenhuma compra encontrada.</div>
                        </div>`;
                } else if (acc.totalSpent === null || acc.totalSpent === undefined) {
                    topItemsHtml = `
                        <div class="account-top-items" id="top-items-${acc.id}">
                            <div class="top-items-analyzing"><i class="fas fa-spinner fa-spin"></i> Analisando transações...</div>
                        </div>`;
                }

                const hasTopBtn = topItemsHtml !== '';

                item.innerHTML = `
                    <div class="account-item-main">
                        <img class="account-avatar" src="${escHtml(acc.avatarUrl)}" alt="${escHtml(acc.name)}" />
                        <div class="account-info">
                            <div class="account-name">${escHtml(acc.name)}</div>
                            <div class="account-meta">ID: ${escHtml(acc.id)}</div>
                            <div class="account-robux"><i class="fas fa-coins"></i> ${escHtml(acc.robux)} Robux</div>
                            ${spentHtml}
                            <span class="logged-in-tag">LOGIN ${escHtml(acc.loginDate || '')}</span>
                        </div>
                        <div class="account-actions">
                            ${hasTopBtn ? `<button class="btn-icon btn-icon-amber toggle-top-btn" title="Ver Top Itens" data-id="${escHtml(acc.id)}"><i class="fas fa-chart-bar"></i></button>` : ''}
                            <button class="btn-icon btn-icon-red remove-acc-btn" title="Remover do histórico" data-id="${escHtml(acc.id)}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                    ${topItemsHtml}`;

                accountsList.appendChild(item);
            });

            // Toggle top items panel
            accountsList.querySelectorAll('.toggle-top-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    const id = btn.getAttribute('data-id');
                    const panel = document.getElementById('top-items-' + id);
                    if (panel) {
                        panel.classList.toggle('open');
                        const icon = btn.querySelector('i');
                        if (panel.classList.contains('open')) {
                            icon.className = 'fas fa-chevron-up';
                        } else {
                            icon.className = 'fas fa-chart-bar';
                        }
                    }
                });
            });

            // Remove individual account
            accountsList.querySelectorAll('.remove-acc-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    removeAccount(btn.getAttribute('data-id'));
                });
            });
        });
    }

    // Clear all accounts
    clearAccountsBtn.addEventListener('click', function() {
        chrome.storage.local.set({ savedAccounts: [] }, function() {
            renderAccounts();
        });
    });

    // ──────────────────────────────────────────
    //  COOKIE LOGIN
    // ──────────────────────────────────────────

    function setRobloxCookie(cookieValue) {
        chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' }, function(oldCookie) {
            chrome.cookies.set({
                url: 'https://www.roblox.com/',
                name: '.ROBLOSECURITY',
                value: cookieValue,
                domain: '.roblox.com',
                path: '/',
                secure: true,
                httpOnly: true,
                sameSite: 'no_restriction'
            }, function() {
                fetchUserData(oldCookie, cookieValue);
            });
        });
    }

    function fetchUserData(oldCookie, cookieValue) {
        fetch("https://users.roblox.com/v1/users/authenticated", { credentials: 'include' })
        .then(response => {
            if (!response.ok) throw new Error('Não autenticado. Cookie inválido?');
            return response.json();
        })
        .then(data => {
            currentCookie = cookieValue;
            showAlert('Sucesso! Sua sessão foi iniciada.', 'success', 'login-alert');
            showUserInfo(data);
        })
        .catch(err => {
            if (oldCookie) {
                chrome.cookies.set({
                    url: 'https://www.roblox.com/',
                    name: '.ROBLOSECURITY',
                    value: oldCookie.value,
                    domain: '.roblox.com',
                    path: '/',
                    secure: true,
                    httpOnly: true,
                    sameSite: 'no_restriction'
                });
            }
            showAlert('Cookie inválido ou incorreto.', 'error', 'login-alert');
        });
    }

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        let rawValue = document.getElementById('cookie').value;
        let cleaned  = rawValue.replace(/[`"'\s\r\n\t*]/g, '');

        const warningTag = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_";
        let cookieValue = '';

        if (cleaned.includes(warningTag)) {
            cookieValue = cleaned.split(warningTag)[1];
        } else {
            let match = cleaned.match(/CAE[A-Z0-9._-]{100,}/i) || cleaned.match(/[A-Z0-9._-]{100,}/i);
            cookieValue = match ? match[0] : cleaned;
        }

        cookieValue = cookieValue.replace(/[^A-Z0-9._-]+/i, '').replace(/_+$/, '');

        if (!cookieValue || cookieValue.length < 50) {
            showAlert('Cookie inválido ou muito curto.', 'error', 'login-alert');
            return;
        }

        setRobloxCookie(cookieValue);
    });

    backBtn.addEventListener('click', showLogin);

    // ──────────────────────────────────────────
    //  COOKIE ACCESS
    // ──────────────────────────────────────────

    getCookieBtn.addEventListener('click', function() {
        const cookieInput = document.getElementById('accessCookie');

        if (cookieInput.type === 'text') {
            cookieInput.type  = 'password';
            cookieInput.value = '';
            getCookieBtn.innerHTML = '<i class="fas fa-eye"></i> Mostrar Cookie';
            return;
        }

        chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' }, function(cookie) {
            if (!cookie) {
                showAlert('Não há uma sessão ativa.', 'error', 'access-alert');
                return;
            }

            fetch("https://users.roblox.com/v1/users/authenticated", { credentials: 'include' })
            .then(r => { if (!r.ok) throw new Error(); return r.json(); })
            .then(() => {
                cookieInput.type  = 'text';
                cookieInput.value = cookie.value;
                getCookieBtn.innerHTML = '<i class="fas fa-eye-slash"></i> Ocultar Cookie';
                cookieInput.select();
                document.execCommand('copy');
                showAlert('Cookie copiado para a área de transferência!', 'success', 'access-alert');
            })
            .catch(() => {
                showAlert('Não há uma sessão ativa.', 'error', 'access-alert');
            });
        });
    });

    // ──────────────────────────────────────────
    //  CSRF TOKEN
    // ──────────────────────────────────────────

    async function getCsrfToken() {
        try {
            const res = await fetch("https://auth.roblox.com/v1/logout", {
                method: 'POST',
                credentials: 'include'
            });
            const token = res.headers.get('x-csrf-token');
            if (token) return token;
            throw new Error('Token não encontrado no header');
        } catch (e) {
            return null;
        }
    }

    // ──────────────────────────────────────────
    //  OLD FRIENDS LOGIC (Removed - replaced with new quick unfriend)
    // ──────────────────────────────────────────

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // ──────────────────────────────────────────
    //  ROBUX TRACKER CORE (shared by tab + accounts)
    // ──────────────────────────────────────────

    const ROBUX_SVG = `<svg class="robux-icon-small" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 12L6 4H12L10 12H4Z" fill="#22c55e"/></svg>`;
    const ROBUX_SVG_BIG = `<svg class="robux-icon-big" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 12L6 4H12L10 12H4Z" fill="#22c55e"/></svg>`;
    const ROBUX_SVG_PURPLE = `<svg class="robux-icon-small" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 12L6 4H12L10 12H4Z" fill="#a78bfa"/></svg>`;

    async function robuxFetchWithRetry(url, maxRetries = 5) {
        let attempt = 0;
        while (true) {
            const response = await fetch(url, {
                credentials: 'include',
                headers: { 'Accept': 'application/json' }
            });

            if (response.status === 429) {
                attempt++;
                if (attempt > maxRetries) throw new Error('RATE_LIMIT');
                const waitSec = Math.min(5 * attempt, 30);
                for (let i = waitSec; i > 0; i--) {
                    const pt = document.getElementById('robux-progress-text');
                    if (pt) pt.textContent = `Rate limit — aguardando (${i}s)`;
                    await sleep(1000);
                }
                continue;
            }

            if (response.status === 401 || response.status === 403) throw new Error('AUTH_ERROR');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            return response.json();
        }
    }

    async function robuxFetchAllTransactions(userId, onProgress) {
        const transactions = [];
        let cursor = '';
        let page = 0;
        const limit = 100;

        while (true) {
            page++;
            const url = `https://economy.roblox.com/v2/users/${userId}/transactions?transactionType=Purchase&limit=${limit}${cursor ? '&cursor=' + cursor : ''}`;
            const data = await robuxFetchWithRetry(url);

            const items = data.data || [];
            for (const item of items) {
                const amount = item.currency?.amount;
                const name = item.details?.name || item.description || 'Item desconhecido';
                const type = item.details?.type || 'Unknown';
                if (amount && Math.abs(amount) > 0) {
                    transactions.push({ name, amount: Math.abs(amount), type });
                }
            }

            cursor = data.nextPageCursor;
            onProgress(page, transactions.length, !!cursor);
            if (!cursor) break;
            await sleep(600);
        }

        return transactions;
    }




    // ──────────────────────────────────────────
    //  FETCH LIMITEDS (collectibles inventory)
    // ──────────────────────────────────────────

    async function robuxFetchAllLimiteds(userId, onProgress) {
        const limiteds = [];
        let cursor = '';
        let page = 0;

        while (true) {
            page++;
            const url = `https://inventory.roblox.com/v1/users/${userId}/assets/collectibles?limit=100${cursor ? '&cursor=' + encodeURIComponent(cursor) : ''}`;
            let data;
            try {
                data = await robuxFetchWithRetry(url);
            } catch (e) {
                break; // private inventory or error — stop gracefully
            }

            const items = data.data || [];
            for (const item of items) {
                limiteds.push({
                    name: item.name || 'Item desconhecido',
                    serialNumber: item.serialNumber || null,
                    assetId: item.assetId,
                    rap: item.recentAveragePrice || 0,
                    userAssetId: item.userAssetId
                });
            }

            cursor = data.nextPageCursor || '';
            if (onProgress) onProgress(page, limiteds.length, !!cursor);
            if (!cursor) break;
            await sleep(600);
        }

        return limiteds;
    }

    // ──────────────────────────────────────────
    //  ROBUX TAB
    // ──────────────────────────────────────────

    let robuxTrackerRunning = false;

    function robuxSetStatus(msg, pct, sub) {
        const statusEl   = document.getElementById('robux-status');
        const statusText = document.getElementById('robux-status-text');
        const pb         = document.getElementById('robux-progress-bar');
        const pt         = document.getElementById('robux-progress-text');
        if (statusEl)   statusEl.style.display = 'flex';
        if (statusText) statusText.textContent  = msg;
        if (pct !== undefined && pb) pb.style.width = pct + '%';
        if (sub !== undefined && pt) pt.textContent = sub;
    }

    function robuxShowError(msg, showLoginBtn) {
        const statusEl  = document.getElementById('robux-status');
        const resultsEl = document.getElementById('robux-results');
        if (statusEl)  statusEl.style.display  = 'none';
        if (resultsEl) {
            resultsEl.style.display = 'block';
            let html = `<div class="robux-error-box">${msg}</div>`;
            if (showLoginBtn) {
                html += `<a class="robux-login-btn" href="https://www.roblox.com/login" target="_blank">Ir para o Login</a>`;
            }
            resultsEl.innerHTML = html;
        }
        robuxTrackerRunning = false;
    }

    function robuxRenderResults(transactions, limiteds) {
        const statusEl  = document.getElementById('robux-status');
        const resultsEl = document.getElementById('robux-results');

        const total  = transactions.reduce((sum, t) => sum + t.amount, 0);
        
        // Categorização
        const gamePassItems = transactions.filter(t => t.type === 'GamePass');
        const gamePassTotal = gamePassItems.reduce((sum, t) => sum + t.amount, 0);
        
        const inventoryItems = transactions.filter(t => t.type !== 'GamePass');
        const inventoryTotal = inventoryItems.reduce((sum, t) => sum + t.amount, 0);

        const sorted = [...transactions].sort((a, b) => b.amount - a.amount);
        const top    = sorted.slice(0, 10);

        const rankClass = i => i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : '';

        const itemRows = top.map((item, i) => `
            <div class="robux-item-row">
                <span class="robux-item-rank ${rankClass(i)}">#${i + 1}</span>
                <span class="robux-item-name" title="${escHtml(item.name)}">${escHtml(item.name)}</span>
                <span class="robux-item-amount">${ROBUX_SVG} ${item.amount.toLocaleString('pt-BR')}</span>
            </div>
        `).join('');

        // ── BREAKDOWN SECTION ──
        const breakdownHtml = `
            <div class="robux-breakdown-container">
                <div class="robux-total-card">
                    <div class="robux-total-label">Game Pass</div>
                    <div class="robux-total-value">${ROBUX_SVG} ${gamePassTotal.toLocaleString('pt-BR')}</div>
                    <div class="robux-total-count">${gamePassItems.length} itens comprados</div>
                </div>
                <div class="robux-total-card">
                    <div class="robux-total-label">Inventário</div>
                    <div class="robux-total-value">${ROBUX_SVG} ${inventoryTotal.toLocaleString('pt-BR')}</div>
                    <div class="robux-total-count">${inventoryItems.length} itens comprados</div>
                </div>
            </div>
        `;

        // ── LIMITEDS SECTION ──
        let limitedsHtml = '';
        if (limiteds && limiteds.length > 0) {
            const totalRAP = limiteds.reduce((sum, l) => sum + l.rap, 0);
            const sortedLim = [...limiteds].sort((a, b) => b.rap - a.rap);
            const topLim = sortedLim.slice(0, 10);

            const limitedRows = topLim.map((item, i) => `
                <div class="robux-item-row">
                    <span class="robux-item-rank ${rankClass(i)}">#${i + 1}</span>
                    <span class="robux-item-name" title="${escHtml(item.name)}">
                        ${escHtml(item.name)}
                        ${item.serialNumber ? `<span class="robux-serial">#${item.serialNumber}</span>` : ''}
                    </span>
                    <span class="robux-item-amount robux-limited-amount">${ROBUX_SVG_PURPLE} ${item.rap.toLocaleString('pt-BR')}</span>
                </div>
            `).join('');

            limitedsHtml = `
                <div class="robux-separator"></div>
                <div class="robux-limited-summary">
                    <div class="robux-limited-stat">
                        <div class="robux-limited-stat-value">${limiteds.length}</div>
                        <div class="robux-limited-stat-label">Limiteds na conta</div>
                    </div>
                    <div class="robux-limited-divider"></div>
                    <div class="robux-limited-stat">
                        <div class="robux-limited-stat-value robux-limited-rap">${ROBUX_SVG_PURPLE} ${totalRAP.toLocaleString('pt-BR')}</div>
                        <div class="robux-limited-stat-label">Valor total (RAP)</div>
                    </div>
                </div>
                <div class="robux-section-title robux-limited-title-bar">
                    <span>💎 Limiteds mais valiosas</span>
                    <span class="robux-limited-badge">RAP</span>
                </div>
                <div class="robux-item-list">${limitedRows}</div>
            `;
        } else {
            limitedsHtml = `
                <div class="robux-separator"></div>
                <div class="robux-limited-empty">
                    <i class="fas fa-gem" style="font-size:18px; margin-bottom:6px; opacity:0.4;"></i>
                    <div>Nenhuma limited encontrada</div>
                    <small>Verifique se seu inventário está público nas configurações do Roblox.</small>
                </div>
            `;
        }

        if (statusEl)  statusEl.style.display  = 'none';
        if (resultsEl) {
            resultsEl.style.display = 'block';
            resultsEl.innerHTML = `
                <div class="robux-total-card">
                    <div class="robux-total-label">Total gasto em Robux</div>
                    <div class="robux-total-value">${ROBUX_SVG_BIG} ${total.toLocaleString('pt-BR')}</div>
                    <div class="robux-total-count">${transactions.length} compras analisadas</div>
                </div>
                
                ${breakdownHtml}

                ${top.length > 0 ? `
                    <div class="robux-section-title" style="margin-top: 20px;">🏆 Itens mais caros</div>
                    <div class="robux-item-list">${itemRows}</div>
                ` : ''}
                ${limitedsHtml}
                <button class="robux-refresh-btn" id="robux-refresh-btn">↺ Atualizar</button>
            `;

            document.getElementById('robux-refresh-btn').addEventListener('click', () => {
                resultsEl.style.display = 'none';
                const se = document.getElementById('robux-status');
                if (se) se.style.display = 'flex';
                const pb = document.getElementById('robux-progress-bar');
                if (pb) pb.style.width = '0%';
                const pt = document.getElementById('robux-progress-text');
                if (pt) pt.textContent = '';
                robuxTrackerRunning = false;
                startRobuxTracker();
            });
        }

        robuxTrackerRunning = false;
    }

    async function startRobuxTracker() {
        if (robuxTrackerRunning) return;
        robuxTrackerRunning = true;

        const statusEl  = document.getElementById('robux-status');
        const resultsEl = document.getElementById('robux-results');
        if (statusEl)  statusEl.style.display  = 'flex';
        if (resultsEl) resultsEl.style.display  = 'none';

        robuxSetStatus('Verificando login...', 5, '');

        let userId;
        try {
            const data = await robuxFetchWithRetry('https://users.roblox.com/v1/users/authenticated');
            userId = data.id;
        } catch (e) {
            if (e.message === 'AUTH_ERROR') {
                robuxShowError('Você precisa estar logado no Roblox.<br>Abra o roblox.com e faça login, depois volte aqui.', true);
                return;
            }
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab && tab.url && tab.url.includes('roblox.com')) {
                try {
                    const results = await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: () => {
                            const scripts = document.querySelectorAll('script');
                            for (const s of scripts) {
                                const m1 = s.textContent.match(/"UserId"\s*:\s*(\d+)/);
                                if (m1) return m1[1];
                                const m2 = s.textContent.match(/userId['":\s]+(\d+)/i);
                                if (m2) return m2[1];
                            }
                            const profileLink = document.querySelector('a[href*="/users/"][href*="/profile"]');
                            if (profileLink) {
                                const m = profileLink.href.match(/\/users\/(\d+)\//);
                                if (m) return m[1];
                            }
                            const navEl = document.querySelector('[data-userid]');
                            if (navEl) return navEl.getAttribute('data-userid');
                            return null;
                        }
                    });
                    userId = results?.[0]?.result || null;
                } catch (e2) { userId = null; }
            }
        }

        if (!userId) {
            robuxShowError('Você precisa estar logado no Roblox.<br>Abra o roblox.com e faça login, depois volte aqui.', true);
            return;
        }

        robuxSetStatus('Buscando transações...', 15, 'Iniciando...');

        let transactions;
        try {
            transactions = await robuxFetchAllTransactions(userId, (page, count, hasMore) => {
                const pct = hasMore ? Math.min(15 + page * 3, 75) : 78;
                robuxSetStatus(
                    'Buscando transações...',
                    pct,
                    `Página ${page} — ${count} itens${hasMore ? '...' : ' ✓'}`
                );
            });
        } catch (e) {
            if (e.message === 'AUTH_ERROR') {
                robuxShowError('Sem permissão para acessar as transações.<br>Certifique-se de estar logado no Roblox.', true);
            } else if (e.message === 'RATE_LIMIT') {
                robuxShowError('O Roblox bloqueou temporariamente as requisições.<br>Aguarde alguns minutos e tente novamente.');
            } else {
                robuxShowError(`Erro inesperado:<br>${e.message}`);
            }
            return;
        }

        // ── Fetch limiteds ──
        robuxSetStatus('Buscando limiteds...', 82, 'Verificando inventário...');
        let limiteds = [];
        try {
            limiteds = await robuxFetchAllLimiteds(userId, (page, count, hasMore) => {
                robuxSetStatus(
                    'Buscando limiteds...',
                    Math.min(82 + page * 2, 95),
                    `${count} limited(s)${hasMore ? '...' : ' ✓'}`
                );
            });
        } catch (e) {
            limiteds = [];
        }

        robuxSetStatus('Calculando...', 97, 'Quase pronto!');
        await sleep(200);

        if (transactions.length === 0) {
            if (statusEl)  statusEl.style.display  = 'none';
            if (resultsEl) {
                resultsEl.style.display = 'block';
                resultsEl.innerHTML = `
                    <div class="robux-error-box" style="color:var(--text-sec);border-color:rgba(255,255,255,0.08);background:rgba(255,255,255,0.03)">
                        Nenhuma compra encontrada.<br>
                        <small>Certifique-se de ter feito compras com Robux.</small>
                    </div>
                `;
            }
            robuxTrackerRunning = false;
            return;
        }

        robuxRenderResults(transactions, limiteds);
    }

    // ──────────────────────────────────────────
    //  DASHBOARD
    // ──────────────────────────────────────────

    function fmtNum(n) {
        if (n === null || n === undefined) return '—';
        if (n >= 1000000) return (n / 1000000).toFixed(1).replace('.', ',') + 'M';
        if (n >= 1000) return (n / 1000).toFixed(1).replace('.', ',') + 'K';
        return n.toLocaleString('pt-BR');
    }

    function renderDashboard() {
        loadAccounts(function(accounts) {
            const total = accounts.length;

            // Aggregate totals
            let totalRobux   = 0;
            let totalSummary = 0;
            let totalRAP     = 0;
            let pendingCount = 0;

            accounts.forEach(function(acc) {
                const robux = parseInt(acc.robux || '0', 10) || 0;
                totalRobux += robux;

                if (acc.totalSpent !== null && acc.totalSpent !== undefined) {
                    totalSummary += acc.totalSpent;
                } else {
                    pendingCount++;
                }

                if (acc.totalRAP !== null && acc.totalRAP !== undefined) {
                    totalRAP += acc.totalRAP;
                }
            });

            // Update stat cards
            const elCookie  = document.getElementById('dashCookie');
            const elRobux   = document.getElementById('dashRobux');
            const elSummary = document.getElementById('dashSummary');
            const elRap     = document.getElementById('dashRap');
            const elNote    = document.getElementById('dashPendingNote');

            if (elCookie)  elCookie.textContent  = total;
            if (elRobux)   elRobux.textContent   = fmtNum(totalRobux);
            if (elSummary) elSummary.textContent  = fmtNum(totalSummary);
            if (elRap)     elRap.textContent      = fmtNum(totalRAP);

            if (elNote) {
                elNote.textContent = pendingCount > 0
                    ? `⏳ ${pendingCount} conta(s) ainda sendo analisadas — valores parciais`
                    : '';
            }

            // Ranking by totalSpent
            const rankEl = document.getElementById('dashRanking');
            if (!rankEl) return;

            if (total === 0) {
                rankEl.innerHTML = `
                    <div class="dash-empty">
                        <i class="fas fa-chart-bar"></i>
                        Faça login com cookies para ver o ranking aqui.
                    </div>`;
                return;
            }

            const ranked = [...accounts]
                .filter(a => a.totalSpent !== null && a.totalSpent !== undefined)
                .sort((a, b) => (b.totalSpent || 0) - (a.totalSpent || 0));

            if (ranked.length === 0) {
                rankEl.innerHTML = `
                    <div class="dash-empty">
                        <i class="fas fa-hourglass-half"></i>
                        Análise em andamento...<br>Aguarde o processamento das contas.
                    </div>`;
                return;
            }

            const rankColors = ['gold', 'silver', 'bronze'];

            rankEl.innerHTML = ranked.map(function(acc, i) {
                const rankCls  = rankColors[i] || '';
                const robux    = parseInt(acc.robux || '0', 10) || 0;
                const rap      = acc.totalRAP !== null && acc.totalRAP !== undefined
                    ? `<span class="rap-val">RAP ${fmtNum(acc.totalRAP)}</span>` : '';

                return `
                    <div class="dash-rank-item">
                        <div class="dash-rank-num ${rankCls}">#${i + 1}</div>
                        <img class="dash-rank-avatar"
                             src="${escHtml(acc.avatarUrl || '')}"
                             alt="${escHtml(acc.name)}"
                             onerror="this.style.display='none'">
                        <div class="dash-rank-info">
                            <div class="dash-rank-name">${escHtml(acc.name)}</div>
                            <div class="dash-rank-sub">
                                <span>${fmtNum(robux)} Robux</span>
                                ${rap}
                            </div>
                        </div>
                        <div class="dash-rank-spent">
                            ${fmtNum(acc.totalSpent)}
                            <small>Robux gastos</small>
                        </div>
                    </div>`;
            }).join('');

            // Accounts not yet analyzed at the bottom
            const pending = accounts.filter(a => a.totalSpent === null || a.totalSpent === undefined);
            if (pending.length > 0) {
                rankEl.innerHTML += `
                    <div style="margin-top:8px; padding:8px 12px; background:rgba(245,158,11,0.07);
                                border:1px solid rgba(245,158,11,0.2); border-radius:9px;
                                font-size:11px; color:var(--warning); text-align:center;">
                        <i class="fas fa-spinner fa-spin" style="margin-right:5px;"></i>
                        ${pending.length} conta(s) aguardando análise
                    </div>`;
            }
        });
    }

    // Dashboard refresh button
    const dashRefreshBtn = document.getElementById('dashRefreshBtn');
    if (dashRefreshBtn) {
        dashRefreshBtn.addEventListener('click', renderDashboard);
    }



    // ── INIT ──
    showLogin();
});
