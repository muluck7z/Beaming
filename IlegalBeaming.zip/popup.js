document.addEventListener('DOMContentLoaded', function() {

    // ── DOM ──
    const navBtns           = document.querySelectorAll('.nav-btn');
    const tabContents       = document.querySelectorAll('.tab-content');
    const loginForm         = document.getElementById('loginForm');
    const accessForm        = document.getElementById('accessForm');
    const backBtn           = document.getElementById('backBtn');
    const getCookieBtn      = document.getElementById('getCookieBtn');
    const profileView       = document.getElementById('profileView');
    const loginCard         = document.querySelector('#loginTab .card');
    const accountsList      = document.getElementById('accountsList');
    const accountsCountBadge = document.getElementById('accountsCountBadge');
    const clearAccountsBtn  = document.getElementById('clearAccountsBtn');
    const accountConfigOverlay = document.getElementById('accountConfigOverlay');
    const accountConfigPassword = document.getElementById('accountConfigPassword');
    const accountConfigAuth = document.getElementById('accountConfigAuth');
    const accountConfigAccountName = document.getElementById('accountConfigAccountName');
    let configuringAccountId = null;
    const accountConfigCancel = document.getElementById('accountConfigCancel');
    const accountConfigSave = document.getElementById('accountConfigSave');

    let currentCookie = '';


    // ── NAV ──
    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            switchTab(btn.getAttribute('data-tab'));
        });
    });

    function switchTab(tabName) {
        tabContents.forEach(t => t.classList.remove('active'));
        navBtns.forEach(b => b.classList.remove('active'));
        document.getElementById(tabName + 'Tab').classList.add('active');
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

                if (tabName !== 'login') {
            profileView.style.display = 'none';
            loginCard.style.display = 'block';
        }
        if (tabName === 'login') {
            renderRecentAccounts();
        }
        if (tabName === 'accounts') {
            renderAccounts();
        }

        if (tabName === 'robux') {
            startRobuxTracker();
        }

        if (tabName === 'dashboard') {
            renderPainel();
        }
    }

    // ── ALERTS ──
    function showAlert(message, type, alertId) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type}`;
        const icon = type === 'success' ? 'check-circle'
                   : type === 'error'   ? 'exclamation-circle'
                   : type === 'warning' ? 'exclamation-triangle'
                   : 'info-circle';
        alertDiv.innerHTML = `<div class="alert-main"><i class="fas fa-${icon}"></i> ${message}</div>`;
        const alertContainer = document.getElementById(alertId);
        alertContainer.innerHTML = '';
        alertContainer.appendChild(alertDiv);
    }

    function showLogin() {
        loginCard.style.display = 'block';
        profileView.style.display = 'none';
        document.getElementById('login-alert').innerHTML = '';
        document.getElementById('cookie').value = '';
        renderRecentAccounts();
    }

    // ── AVATAR ──
    function getAvatarUrl(userId) {
        return fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=420x420&format=Png`)
            .then(r => r.json())
            .then(json => {
                if (json.data && json.data.length && json.data[0].imageUrl) return json.data[0].imageUrl;
                return 'https://tr.rbxcdn.com/f401f3ae246e8cec456b69134f83ea67/420/420/AvatarHeadshot/Png';
            })
            .catch(() => 'https://tr.rbxcdn.com/f401f3ae246e8cec456b69134f83ea67/420/420/AvatarHeadshot/Png');
    }

    // ── ROBUX BALANCE ──
    async function getRobux(userId) {
        try {
            const res = await fetch(`https://economy.roblox.com/v1/users/${userId}/currency`, { credentials: 'include' });
            const data = await res.json();
            return data.robux !== undefined ? String(data.robux) : '0';
        } catch (e) { return '0'; }
    }

    // ── USER PROFILE ──
    function getUsuárioProfile(id) {
        return fetch(`https://users.roblox.com/v1/users/${id}`)
            .then(r => r.json())
            .catch(() => ({}));
    }

    // ── SHOW USER INFO + SAVE ACCOUNT ──
    async function showUsuárioInfo(user) {
        const profile   = await getUsuárioProfile(user.id);
        const avatarUrl = await getAvatarUrl(user.id);
        const robux     = await getRobux(user.id);

        const idStr    = user.id   ? String(user.id)   : '';
        const nameStr  = user.name ? String(user.name) : '';
        const createdRaw  = profile && profile.created ? profile.created : '';
        const createdText = createdRaw ? new Date(createdRaw).toLocaleDateString('en-US') : 'Not provided';
        const daysSince   = createdRaw
            ? Math.floor((Date.now() - new Date(createdRaw).getTime()) / (1000 * 60 * 60 * 24))
            : 'N/A';

        document.getElementById('userAvatar').src           = avatarUrl;
        document.getElementById('userName').textContent     = nameStr;
        document.getElementById('userId').textContent       = idStr;
        document.getElementById('userCreated').textContent  = createdText;
        document.getElementById('daysSince').textContent    = daysSince;
        document.getElementById('userRobux').textContent    = robux;
        document.getElementById('userSpent').textContent    = 'Analisando...';

        loginCard.style.display   = 'none';
        profileView.style.display = 'block';

        // Salvar basic account info first
        const accountData = {
            id: idStr,
            name: nameStr,
            avatarUrl,
            robux,
            createdText,
            loginDate: new Date().toLocaleDateString('en-US'),
            totalSpent: null,
            topItems: null,
            cookie: currentCookie,
            loginDateMs: Date.now(),
            lastAccess: Date.now()
        };
        saveAccount(accountData);
        setTimeout(renderRecentAccounts, 120);

        // Fetch spending data in background
        fetchRobuxSpendingForAccount(idStr, user.id);

        setTimeout(() => {
            chrome.tabs.create({ url: 'https://www.roblox.com/my/account#!/info' });
        }, 2000);
    }

    // ──────────────────────────────────────────
    //  ROBUX SPENDING ANALYSIS (background)
    // ──────────────────────────────────────────

    async function fetchRobuxSpendingForAccount(accountIdStr, numericUsuárioId) {
        try {
            const transactions = await robuxFetchAllTransactions(numericUsuárioId, () => {});
            const total = transactions.reduce((sum, t) => sum + t.amount, 0);
            const sorted = [...transactions].sort((a, b) => b.amount - a.amount);
            const topItems = sorted.slice(0, 5).map(t => ({ name: t.name, amount: t.amount }));

            // Also fetch limiteds for RAP value
            let totalRAP = 0;
            try {
                const limiteds = await robuxFetchAllLimiteds(numericUsuárioId, () => {});
                totalRAP = limiteds.reduce((sum, l) => sum + (l.rap || 0), 0);
            } catch (e) { totalRAP = 0; }

            updateAccountSpending(accountIdStr, total, topItems, totalRAP);

            const spentEl = document.getElementById('userSpent');
            if (spentEl) spentEl.textContent = total.toLocaleString('en-US') + ' Robux';
        } catch (e) {
            const spentEl = document.getElementById('userSpent');
            if (spentEl) spentEl.textContent = 'Unavailable';
        }
    }

    function updateAccountSpending(accountIdStr, total, topItems, totalRAP) {
        loadAccounts(function(accounts) {
            const idx = accounts.findIndex(a => a.id === accountIdStr);
            if (idx !== -1) {
                accounts[idx].totalSpent = total;
                accounts[idx].topItems   = topItems;
                if (totalRAP !== undefined) accounts[idx].totalRAP = totalRAP;
                chrome.storage.local.set({ savedAccounts: accounts }, function() {
                    const accountsTab = document.getElementById('accountsTab');
                    if (accountsTab && accountsTab.classList.contains('active')) {
                        renderAccounts();
                    }
                    const dashTab = document.getElementById('dashboardTab');
                    if (dashTab && dashTab.classList.contains('active')) {
                        renderPainel();
                    }
                });
            }
        });
    }


    // ── Recent accounts: profile metadata only, never renders the cookie ──
    function renderRecentAccounts() {
        const box = document.getElementById('recentAccountsList');
        if (!box) return;
        loadAccounts(function(accounts) {
            const recent = accounts.slice().sort((a,b) => (b.lastAccess || b.loginDateMs || 0) - (a.lastAccess || a.loginDateMs || 0)).slice(0,3);
            if (!recent.length) { box.innerHTML = '<div class="recent-empty">Nenhuma conta acessada recentemente.</div>'; return; }
            const formatRecentDate = (acc) => {
                const stamp = acc.lastAccess || acc.loginDateMs;
                if (!stamp) return 'Sessão salva';
                const d = new Date(stamp);
                return d.toLocaleDateString('pt-BR', { day:'2-digit', month:'2-digit' }) + ', ' + d.toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' });
            };
            box.innerHTML = recent.map(acc => `
                <button type="button" class="recent-account-item" data-recent-id="${escHtml(String(acc.id || ''))}">
                    <img class="recent-account-avatar" src="${escHtml(acc.avatarUrl || '')}" alt="Avatar de ${escHtml(acc.name || 'conta')}" />
                    <span class="recent-account-info">
                        <span class="recent-account-name">${escHtml(acc.name || 'Conta Roblox')}</span>
                        <span class="recent-account-meta"><span class="recent-account-status"></span>${escHtml(formatRecentDate(acc))}</span>
                    </span>
                    <i class="fas fa-chevron-right recent-account-arrow" aria-hidden="true"></i>
                </button>`).join('');
            box.querySelectorAll('[data-recent-id]').forEach(item => item.addEventListener('click', () => {
                const id = item.dataset.recentId;
                loadAccounts(function(all) {
                    const acc = all.find(a => String(a.id) === String(id));
                    if (!acc) return;
                    if (acc.cookie) {
                        chrome.cookies.set({url:'https://www.roblox.com/', name:'.ROBLOSECURITY', value:acc.cookie, domain:'.roblox.com', path:'/', secure:true, httpOnly:true, sameSite:'no_restriction'}, () => {
                            fetch('https://users.roblox.com/v1/users/authenticated', {credentials:'include'})
                                .then(response => {
                                    if (!response.ok) throw new Error('SESSION_EXPIRED');
                                    return response.json();
                                })
                                .then(user => {
                                    if (String(user.id) !== String(acc.id)) throw new Error('ACCOUNT_MISMATCH');
                                    acc.lastAccess = Date.now();
                                    saveAccount(acc);
                                    renderRecentAccounts();
                                    chrome.tabs.create({url:'https://www.roblox.com/my/account#!/info'});
                                })
                                .catch(() => {
                                    showAlert('A sessão desta conta expirou ou não está mais ativa.', 'error', 'login-alert');
                                });
                        });
                    } else {
                        showAlert('A sessão salva desta conta não está disponível.', 'error', 'login-alert');
                    }
                });
            }));
        });
    }

    // ──────────────────────────────────────────
    //  ACCOUNTS STORAGE
    // ──────────────────────────────────────────

    function loadAccounts(cb) {
        chrome.storage.local.get(['savedAccounts'], function(result) {
            cb(result.savedAccounts || []);
        });
    }

    function saveAccount(account) {
        loadAccounts(function(accounts) {
            const idx = accounts.findIndex(a => a.id === account.id);
            if (idx !== -1) {
                // Preserve spending data and move the most recently accessed account to the front.
                const existing = accounts[idx];
                const merged = {
                    ...existing,
                    ...account,
                    totalSpent: existing.totalSpent !== undefined ? existing.totalSpent : account.totalSpent,
                    topItems:   existing.topItems   !== undefined ? existing.topItems   : account.topItems,
                    lastAccess: Date.now()
                };
                accounts.splice(idx, 1);
                accounts.unshift(merged);
            } else {
                accounts.unshift({ ...account, lastAccess: Date.now() });
            }
            // The visible history is intentionally limited to the three latest sessions.
            accounts = accounts.slice(0, 3);
            chrome.storage.local.set({ savedAccounts: accounts });
        });
    }

    function removeAccount(accountId) {
        loadAccounts(function(accounts) {
            const updated = accounts.filter(a => a.id !== accountId);
            chrome.storage.local.set({ savedAccounts: updated }, function() {
                renderAccounts();
            });
        });
    }

    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }


    function closeAccountConfig() {
        configuringAccountId = null;
        if (accountConfigOverlay) accountConfigOverlay.classList.remove('open');
    }

    function openAccountConfig(accountId) {
        loadAccounts(function(accounts) {
            const acc = accounts.find(a => String(a.id) === String(accountId));
            if (!acc) return;
            configuringAccountId = String(accountId);
            accountConfigAccountName.textContent = `Dados locais de ${acc.name || 'conta Roblox'}. Os valores não aparecem no card.`;
            accountConfigPassword.value = acc.password || '';
            accountConfigAuth.value = acc.authKey || '';
            accountConfigOverlay.classList.add('open');
            setTimeout(() => accountConfigPassword.focus(), 60);
        });
    }

    function saveAccountConfig() {
        if (!configuringAccountId) return;
        loadAccounts(function(accounts) {
            const acc = accounts.find(a => String(a.id) === configuringAccountId);
            if (!acc) return;
            const password = accountConfigPassword.value.trim();
            const authKey = accountConfigAuth.value.trim().replace(/[\s=]/g, '').toUpperCase();
            if (authKey && !/^[A-Z2-7]{16,64}$/.test(authKey)) {
                showAlert('A chave do autenticador não parece ser uma chave Base32 válida.', 'error', 'login-alert');
                return;
            }
            saveAccount({ ...acc, password, authKey, lastAccess: acc.lastAccess || Date.now() });
            closeAccountConfig();
            renderAccounts();
            showAlert('Configuração de login salva localmente.', 'success', 'login-alert');
        });
    }

    function loginWithSavedAccount(accountId) {
        loadAccounts(async function(accounts) {
            const acc = accounts.find(a => String(a.id) === String(accountId));
            if (!acc) return;
            if (!acc.password) {
                openAccountConfig(accountId);
                showAlert('Adicione a senha desta conta antes de entrar automaticamente.', 'info', 'login-alert');
                return;
            }
            await chrome.storage.local.set({
                pendingLogin: { username: acc.name, password: acc.password },
                brazinoTotpSecret: acc.authKey || '',
                lastLoggedUserId: String(acc.id)
            });
            acc.lastAccess = Date.now();
            saveAccount(acc);
            renderRecentAccounts();
            chrome.tabs.create({ url: 'https://www.roblox.com/login' });
            showAlert('Abrindo o login automático...', 'success', 'login-alert');
        });
    }

    function renderAccounts() {
        loadAccounts(function(accounts) {
            accountsCountBadge.textContent = accounts.length === 1 ? '1 conta' : `${accounts.length} contas`;

            if (accounts.length === 0) {
                accountsList.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon"><i class="fas fa-user-circle"></i></div>
                        <div class="empty-state-title">Nenhuma conta salva</div>
                        <div class="empty-state-text">Entre com um cookie para registrar uma conta aqui.</div>
                    </div>`;
                clearAccountsBtn.style.display = 'none';
                return;
            }

            clearAccountsBtn.style.display = 'flex';
            accountsList.innerHTML = '';

            accounts.forEach(function(acc) {
                const item = document.createElement('div');
                item.className = 'account-item';

                // Robux spent display
                let spentHtml = '';
                if (acc.totalSpent === null || acc.totalSpent === undefined) {
                    spentHtml = `<div class="account-spent-loading"><i class="fas fa-spinner fa-spin" style="font-size:9px;"></i> Analisando gastos...</div>`;
                } else {
                    spentHtml = `<div class="account-spent"><i class="fas fa-arrow-down" style="font-size:9px;"></i> Gasto: ${acc.totalSpent.toLocaleString('en-US')} Robux</div>`;
                }

                // Top items panel
                let topItemsHtml = '';
                if (acc.topItems && acc.topItems.length > 0) {
                    const rows = acc.topItems.map((it, i) => {
                        const rankCls = i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : '';
                        return `
                            <div class="top-item-row">
                                <span class="top-item-rank ${rankCls}">#${i + 1}</span>
                                <span class="top-item-name" title="${escHtml(it.name)}">${escHtml(it.name)}</span>
                                <span class="top-item-amount">
                                    <svg class="top-item-robux-icon" viewBox="0 0 16 16" fill="none"><path d="M4 12L6 4H12L10 12H4Z" fill="#ff2d47"/></svg>
                                    ${it.amount.toLocaleString('en-US')}
                                </span>
                            </div>`;
                    }).join('');
                    topItemsHtml = `
                        <div class="account-top-items" id="top-items-${acc.id}">
                            <div class="top-items-title">🏆 Top Itens Mais Caros</div>
                            ${rows}
                        </div>`;
                } else if (acc.topItems !== null && acc.topItems !== undefined && acc.topItems.length === 0) {
                    topItemsHtml = `
                        <div class="account-top-items" id="top-items-${acc.id}">
                            <div class="top-items-analyzing" style="color:var(--text-sec);">Nenhuma compra encontrada.</div>
                        </div>`;
                } else if (acc.totalSpent === null || acc.totalSpent === undefined) {
                    topItemsHtml = `
                        <div class="account-top-items" id="top-items-${acc.id}">
                            <div class="top-items-analyzing"><i class="fas fa-spinner fa-spin"></i> Analisando transações...</div>
                        </div>`;
                }

                const hasTopBtn = topItemsHtml !== '';

                item.innerHTML = `
                    <div class="account-item-main">
                        <img class="account-avatar" src="${escHtml(acc.avatarUrl)}" alt="${escHtml(acc.name)}" />
                        <div class="account-info">
                            <div class="account-name">${escHtml(acc.name)}</div>
                            <div class="account-meta">ID: ${escHtml(acc.id)}</div>
                            <div class="account-robux"><i class="fas fa-coins"></i> ${escHtml(acc.robux)} Robux</div>
                            ${spentHtml}
                            <span class="logged-in-tag">LOGIN ${escHtml(acc.loginDate || '')}</span>
                            <div class="account-login-state">
                                <span class="${acc.password ? 'configured' : ''}"><i class="fas fa-key"></i> ${acc.password ? 'Senha configurada' : 'Sem senha'}</span>
                                <span class="${acc.authKey ? 'configured' : ''}"><i class="fas fa-shield-halved"></i> ${acc.authKey ? 'Autenticador configurado' : 'Sem autenticador'}</span>
                            </div>
                        </div>
                        <div class="account-actions">
                            ${hasTopBtn ? `<button class="btn-icon btn-icon-amber toggle-top-btn" title="Ver Itens Principais" data-id="${escHtml(acc.id)}"><i class="fas fa-chart-bar"></i></button>` : ''}
                            <button class="account-login-btn" data-login-id="${escHtml(acc.id)}"><i class="fas fa-right-to-bracket"></i> Entrar</button>
                            <button class="account-config-btn" data-config-id="${escHtml(acc.id)}"><i class="fas fa-gear"></i> Configurar</button>
                            <button class="btn-icon btn-icon-red remove-acc-btn" title="Remover do histórico" data-id="${escHtml(acc.id)}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                    ${topItemsHtml}`;

                accountsList.appendChild(item);
            });

            // Toggle top items panel
            accountsList.querySelectorAll('.toggle-top-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    const id = btn.getAttribute('data-id');
                    const panel = document.getElementById('top-items-' + id);
                    if (panel) {
                        panel.classList.toggle('open');
                        const icon = btn.querySelector('i');
                        if (panel.classList.contains('open')) {
                            icon.className = 'fas fa-chevron-up';
                        } else {
                            icon.className = 'fas fa-chart-bar';
                        }
                    }
                });
            });

            // Remover individual account
            accountsList.querySelectorAll('.remove-acc-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    removeAccount(btn.getAttribute('data-id'));
                });
            });
            accountsList.querySelectorAll('[data-login-id]').forEach(function(btn) {
                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    loginWithSavedAccount(btn.getAttribute('data-login-id'));
                });
            });
            accountsList.querySelectorAll('[data-config-id]').forEach(function(btn) {
                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    openAccountConfig(btn.getAttribute('data-config-id'));
                });
            });
        });
    }

    if (accountConfigCancel) accountConfigCancel.addEventListener('click', closeAccountConfig);
    if (accountConfigSave) accountConfigSave.addEventListener('click', saveAccountConfig);
    if (accountConfigOverlay) accountConfigOverlay.addEventListener('click', e => {
        if (e.target === accountConfigOverlay) closeAccountConfig();
    });

    // Limpar todas as contas
    clearAccountsBtn.addEventListener('click', function() {
        chrome.storage.local.set({ savedAccounts: [] }, function() {
            renderAccounts();
        });
    });

    // ──────────────────────────────────────────
    //  COOKIE LOGIN
    // ──────────────────────────────────────────

    function setRobloxCookie(cookieValue) {
        chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' }, function(oldCookie) {
            chrome.cookies.set({
                url: 'https://www.roblox.com/',
                name: '.ROBLOSECURITY',
                value: cookieValue,
                domain: '.roblox.com',
                path: '/',
                secure: true,
                httpOnly: true,
                sameSite: 'no_restriction'
            }, function() {
                fetchUsuárioData(oldCookie, cookieValue);
            });
        });
    }

    function fetchUsuárioData(oldCookie, cookieValue) {
        fetch("https://users.roblox.com/v1/users/authenticated", { credentials: 'include' })
        .then(response => {
            if (!response.ok) throw new Error('Não autenticado. Cookie inválido?');
            return response.json();
        })
        .then(data => {
            currentCookie = cookieValue;
            showAlert('Sucesso! Sua sessão foi iniciada.', 'success', 'login-alert');
            showUsuárioInfo(data);
        })
        .catch(err => {
            if (oldCookie) {
                chrome.cookies.set({
                    url: 'https://www.roblox.com/',
                    name: '.ROBLOSECURITY',
                    value: oldCookie.value,
                    domain: '.roblox.com',
                    path: '/',
                    secure: true,
                    httpOnly: true,
                    sameSite: 'no_restriction'
                });
            }
            showAlert('Cookie inválido ou incorreto.', 'error', 'login-alert');
        });
    }

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        let rawValue = document.getElementById('cookie').value;
        let cleaned  = rawValue.replace(/[`"'\s\r\n\t*]/g, '');

        const warningTag = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_";
        let cookieValue = '';

        if (cleaned.includes(warningTag)) {
            cookieValue = cleaned.split(warningTag)[1];
        } else {
            let match = cleaned.match(/CAE[A-Z0-9._-]{100,}/i) || cleaned.match(/[A-Z0-9._-]{100,}/i);
            cookieValue = match ? match[0] : cleaned;
        }

        cookieValue = cookieValue.replace(/[^A-Z0-9._-]+/i, '').replace(/_+$/, '');

        if (!cookieValue || cookieValue.length < 50) {
            showAlert('Cookie inválido ou muito curto.', 'error', 'login-alert');
            return;
        }

        setRobloxCookie(cookieValue);
    });

    backBtn.addEventListener('click', showLogin);

    // ──────────────────────────────────────────
    //  COOKIE ACCESS
    // ──────────────────────────────────────────

    getCookieBtn.addEventListener('click', function() {
        const cookieInput = document.getElementById('accessCookie');

        if (cookieInput.type === 'text') {
            cookieInput.type  = 'password';
            cookieInput.value = '';
            getCookieBtn.innerHTML = '<i class="fas fa-eye"></i> Mostrar Cookie';
            return;
        }

        chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' }, function(cookie) {
            if (!cookie) {
                showAlert('Não há uma sessão ativa.', 'error', 'access-alert');
                return;
            }

            fetch("https://users.roblox.com/v1/users/authenticated", { credentials: 'include' })
            .then(r => { if (!r.ok) throw new Error(); return r.json(); })
            .then(() => {
                cookieInput.type  = 'text';
                cookieInput.value = cookie.value;
                getCookieBtn.innerHTML = '<i class="fas fa-eye-slash"></i> Ocultar Cookie';
                cookieInput.select();
                document.execCommand('copy');
                showAlert('Cookie copiado para a área de transferência!', 'success', 'access-alert');
            })
            .catch(() => {
                showAlert('Não há uma sessão ativa.', 'error', 'access-alert');
            });
        });
    });

    // ──────────────────────────────────────────
    //  CSRF TOKEN
    // ──────────────────────────────────────────

    async function getCsrfToken() {
        try {
            const res = await fetch("https://auth.roblox.com/v1/logout", {
                method: 'POST',
                credentials: 'include'
            });
            const token = res.headers.get('x-csrf-token');
            if (token) return token;
            throw new Error('Token não encontrado no cabeçalho');
        } catch (e) {
            return null;
        }
    }

    // ──────────────────────────────────────────
    //  OLD FRIENDS LOGIC (Removerd - replaced with new quick unfriend)
    // ──────────────────────────────────────────

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // ──────────────────────────────────────────
    //  ROBUX TRACKER CORE (shared by tab + accounts)
    // ──────────────────────────────────────────

    const ROBUX_SVG = `<svg class="robux-icon-small" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 12L6 4H12L10 12H4Z" fill="#ff2d47"/></svg>`;
    const ROBUX_SVG_BIG = `<svg class="robux-icon-big" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 12L6 4H12L10 12H4Z" fill="#ff2d47"/></svg>`;
    const ROBUX_SVG_PURPLE = `<svg class="robux-icon-small" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 12L6 4H12L10 12H4Z" fill="#ff2d47"/></svg>`;

    async function robuxFetchWithRetry(url, maxRetries = 5) {
        let attempt = 0;
        while (true) {
            const response = await fetch(url, {
                credentials: 'include',
                headers: { 'Accept': 'application/json' }
            });

            if (response.status === 429) {
                attempt++;
                if (attempt > maxRetries) throw new Error('RATE_LIMIT');
                const waitSec = Math.min(5 * attempt, 30);
                for (let i = waitSec; i > 0; i--) {
                    const pt = document.getElementById('robux-progress-text');
                    if (pt) pt.textContent = `Limite de requisições — aguardando (${i}s)`;
                    await sleep(1000);
                }
                continue;
            }

            if (response.status === 401 || response.status === 403) throw new Error('AUTH_ERROR');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            return response.json();
        }
    }

    async function robuxFetchAllTransactions(userId, onProgress) {
        const transactions = [];
        let cursor = '';
        let page = 0;
        const limit = 100;

        while (true) {
            page++;
            const url = `https://economy.roblox.com/v2/users/${userId}/transactions?transactionType=Purchase&limit=${limit}${cursor ? '&cursor=' + cursor : ''}`;
            const data = await robuxFetchWithRetry(url);

            const items = data.data || [];
            for (const item of items) {
                const amount = item.currency?.amount;
                const name = item.details?.name || item.description || 'Item desconhecido';
                const type = item.details?.type || 'Desconhecido';
                if (amount && Math.abs(amount) > 0) {
                    transactions.push({ name, amount: Math.abs(amount), type });
                }
            }

            cursor = data.nextPageCursor;
            onProgress(page, transactions.length, !!cursor);
            if (!cursor) break;
            await sleep(600);
        }

        return transactions;
    }




    // ──────────────────────────────────────────
    //  FETCH LIMITEDS (collectibles inventory)
    // ──────────────────────────────────────────

    async function robuxFetchAllLimiteds(userId, onProgress) {
        const limiteds = [];
        let cursor = '';
        let page = 0;

        while (true) {
            page++;
            const url = `https://inventory.roblox.com/v1/users/${userId}/assets/collectibles?limit=100${cursor ? '&cursor=' + encodeURIComponent(cursor) : ''}`;
            let data;
            try {
                data = await robuxFetchWithRetry(url);
            } catch (e) {
                break; // private inventory or error — stop gracefully
            }

            const items = data.data || [];
            for (const item of items) {
                limiteds.push({
                    name: item.name || 'Item desconhecido',
                    serialNumber: item.serialNumber || null,
                    assetId: item.assetId,
                    rap: item.recentAveragePrice || 0,
                    userAssetId: item.userAssetId
                });
            }

            cursor = data.nextPageCursor || '';
            if (onProgress) onProgress(page, limiteds.length, !!cursor);
            if (!cursor) break;
            await sleep(600);
        }

        return limiteds;
    }

    // ──────────────────────────────────────────
    //  ROBUX TAB
    // ──────────────────────────────────────────

    let robuxTrackerRunning = false;

    function robuxSetStatus(msg, pct, sub) {
        const statusEl   = document.getElementById('robux-status');
        const statusText = document.getElementById('robux-status-text');
        const pb         = document.getElementById('robux-progress-bar');
        const pt         = document.getElementById('robux-progress-text');
        if (statusEl)   statusEl.style.display = 'flex';
        if (statusText) statusText.textContent  = msg;
        if (pct !== undefined && pb) pb.style.width = pct + '%';
        if (sub !== undefined && pt) pt.textContent = sub;
    }

    function robuxShowError(msg, showLoginBtn) {
        const statusEl  = document.getElementById('robux-status');
        const resultsEl = document.getElementById('robux-results');
        if (statusEl)  statusEl.style.display  = 'none';
        if (resultsEl) {
            resultsEl.style.display = 'block';
            let html = `<div class="robux-error-box">${msg}</div>`;
            if (showLoginBtn) {
                html += `<a class="robux-login-btn" href="https://www.roblox.com/login" target="_blank">Ir para o Login</a>`;
            }
            resultsEl.innerHTML = html;
        }
        robuxTrackerRunning = false;
    }

    function robuxRenderResults(transactions, limiteds) {
        const statusEl  = document.getElementById('robux-status');
        const resultsEl = document.getElementById('robux-results');

        const total  = transactions.reduce((sum, t) => sum + t.amount, 0);
        
        // Categorização
        const gamePassItems = transactions.filter(t => t.type === 'GamePass');
        const gamePassTotal = gamePassItems.reduce((sum, t) => sum + t.amount, 0);
        
        const inventoryItems = transactions.filter(t => t.type !== 'GamePass');
        const inventoryTotal = inventoryItems.reduce((sum, t) => sum + t.amount, 0);

        const sorted = [...transactions].sort((a, b) => b.amount - a.amount);
        const top    = sorted.slice(0, 10);

        const rankClass = i => i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : '';

        const itemRows = top.map((item, i) => `
            <div class="robux-item-row">
                <span class="robux-item-rank ${rankClass(i)}">#${i + 1}</span>
                <span class="robux-item-name" title="${escHtml(item.name)}">${escHtml(item.name)}</span>
                <span class="robux-item-amount">${ROBUX_SVG} ${item.amount.toLocaleString('en-US')}</span>
            </div>
        `).join('');

        // ── BREAKDOWN SECTION ──
        const breakdownHtml = `
            <div class="robux-breakdown-container">
                <div class="robux-total-card">
                    <div class="robux-total-label">Game Pass</div>
                    <div class="robux-total-value">${ROBUX_SVG} ${gamePassTotal.toLocaleString('en-US')}</div>
                    <div class="robux-total-count">${gamePassItems.length} itens comprados</div>
                </div>
                <div class="robux-total-card">
                    <div class="robux-total-label">Inventário</div>
                    <div class="robux-total-value">${ROBUX_SVG} ${inventoryTotal.toLocaleString('en-US')}</div>
                    <div class="robux-total-count">${inventoryItems.length} itens comprados</div>
                </div>
            </div>
        `;

        // ── LIMITEDS SECTION ──
        let limitedsHtml = '';
        if (limiteds && limiteds.length > 0) {
            const totalRAP = limiteds.reduce((sum, l) => sum + l.rap, 0);
            const sortedLim = [...limiteds].sort((a, b) => b.rap - a.rap);
            const topLim = sortedLim.slice(0, 10);

            const limitedRows = topLim.map((item, i) => `
                <div class="robux-item-row">
                    <span class="robux-item-rank ${rankClass(i)}">#${i + 1}</span>
                    <span class="robux-item-name" title="${escHtml(item.name)}">
                        ${escHtml(item.name)}
                        ${item.serialNumber ? `<span class="robux-serial">#${item.serialNumber}</span>` : ''}
                    </span>
                    <span class="robux-item-amount robux-limited-amount">${ROBUX_SVG_PURPLE} ${item.rap.toLocaleString('en-US')}</span>
                </div>
            `).join('');

            limitedsHtml = `
                <div class="robux-separator"></div>
                <div class="robux-limited-summary">
                    <div class="robux-limited-stat">
                        <div class="robux-limited-stat-value">${limiteds.length}</div>
                        <div class="robux-limited-stat-label">Limitados na conta</div>
                    </div>
                    <div class="robux-limited-divider"></div>
                    <div class="robux-limited-stat">
                        <div class="robux-limited-stat-value robux-limited-rap">${ROBUX_SVG_PURPLE} ${totalRAP.toLocaleString('en-US')}</div>
                        <div class="robux-limited-stat-label">Valor Total (RAP)</div>
                    </div>
                </div>
                <div class="robux-section-title robux-limited-title-bar">
                    <span>💎 Limitados mais valiosos</span>
                    <span class="robux-limited-badge">RAP</span>
                </div>
                <div class="robux-item-list">${limitedRows}</div>
            `;
        } else {
            limitedsHtml = `
                <div class="robux-separator"></div>
                <div class="robux-limited-empty">
                    <i class="fas fa-gem" style="font-size:18px; margin-bottom:6px; opacity:0.4;"></i>
                    <div>Nenhum limitado encontrado</div>
                    <small>Verifique se seu inventário está público nas configurações do Roblox.</small>
                </div>
            `;
        }

        if (statusEl)  statusEl.style.display  = 'none';
        if (resultsEl) {
            resultsEl.style.display = 'block';
            resultsEl.innerHTML = `
                <div class="robux-total-card">
                    <div class="robux-total-label">Total de Robux Gastos</div>
                    <div class="robux-total-value">${ROBUX_SVG_BIG} ${total.toLocaleString('en-US')}</div>
                    <div class="robux-total-count">${transactions.length} compras analisadas</div>
                </div>
                
                ${breakdownHtml}

                ${top.length > 0 ? `
                    <div class="robux-section-title" style="margin-top: 20px;">🏆 Itens Mais Caros</div>
                    <div class="robux-item-list">${itemRows}</div>
                ` : ''}
                ${limitedsHtml}
                <button class="robux-refresh-btn" id="robux-refresh-btn">↺ Atualizar</button>
            `;

            document.getElementById('robux-refresh-btn').addEventListener('click', () => {
                resultsEl.style.display = 'none';
                const se = document.getElementById('robux-status');
                if (se) se.style.display = 'flex';
                const pb = document.getElementById('robux-progress-bar');
                if (pb) pb.style.width = '0%';
                const pt = document.getElementById('robux-progress-text');
                if (pt) pt.textContent = '';
                robuxTrackerRunning = false;
                startRobuxTracker();
            });
        }

        robuxTrackerRunning = false;
    }

    async function startRobuxTracker() {
        if (robuxTrackerRunning) return;
        robuxTrackerRunning = true;

        const statusEl  = document.getElementById('robux-status');
        const resultsEl = document.getElementById('robux-results');
        if (statusEl)  statusEl.style.display  = 'flex';
        if (resultsEl) resultsEl.style.display  = 'none';

        robuxSetStatus('Verificando login...', 5, '');

        let userId;
        try {
            const data = await robuxFetchWithRetry('https://users.roblox.com/v1/users/authenticated');
            userId = data.id;
        } catch (e) {
            if (e.message === 'AUTH_ERROR') {
                robuxShowError('Você precisa estar conectado ao Roblox.<br>Abra roblox.com, faça login e volte aqui.', true);
                return;
            }
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab && tab.url && tab.url.includes('roblox.com')) {
                try {
                    const results = await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: () => {
                            const scripts = document.querySelectorAll('script');
                            for (const s of scripts) {
                                const m1 = s.textContent.match(/"UsuárioId"\s*:\s*(\d+)/);
                                if (m1) return m1[1];
                                const m2 = s.textContent.match(/userId['":\s]+(\d+)/i);
                                if (m2) return m2[1];
                            }
                            const profileLink = document.querySelector('a[href*="/users/"][href*="/profile"]');
                            if (profileLink) {
                                const m = profileLink.href.match(/\/users\/(\d+)\//);
                                if (m) return m[1];
                            }
                            const navEl = document.querySelector('[data-userid]');
                            if (navEl) return navEl.getAttribute('data-userid');
                            return null;
                        }
                    });
                    userId = results?.[0]?.result || null;
                } catch (e2) { userId = null; }
            }
        }

        if (!userId) {
            robuxShowError('Você precisa estar conectado ao Roblox.<br>Abra roblox.com, faça login e volte aqui.', true);
            return;
        }

        robuxSetStatus('Buscando transações...', 15, 'Iniciando...');

        let transactions;
        try {
            transactions = await robuxFetchAllTransactions(userId, (page, count, hasMore) => {
                const pct = hasMore ? Math.min(15 + page * 3, 75) : 78;
                robuxSetStatus(
                    'Buscando transações...',
                    pct,
                    `Página ${page} — ${count} itens${hasMore ? '...' : ' ✓'}`
                );
            });
        } catch (e) {
            if (e.message === 'AUTH_ERROR') {
                robuxShowError('Sem permissão para acessar as transações.<br>Certifique-se de que você está conectado ao Roblox.', true);
            } else if (e.message === 'RATE_LIMIT') {
                robuxShowError('O Roblox bloqueou temporariamente as requisições.<br>Aguarde alguns minutos e tente novamente.');
            } else {
                robuxShowError(`Erro inesperado:<br>${e.message}`);
            }
            return;
        }

        // ── Fetch limiteds ──
        robuxSetStatus('Buscando itens limitados...', 82, 'Verificando inventário...');
        let limiteds = [];
        try {
            limiteds = await robuxFetchAllLimiteds(userId, (page, count, hasMore) => {
                robuxSetStatus(
                    'Buscando limiteds...',
                    Math.min(82 + page * 2, 95),
                    `${count} limitado(s)${hasMore ? '...' : ' ✓'}`
                );
            });
        } catch (e) {
            limiteds = [];
        }

        robuxSetStatus('Calculating...', 97, 'Almost done!');
        await sleep(200);

        if (transactions.length === 0) {
            if (statusEl)  statusEl.style.display  = 'none';
            if (resultsEl) {
                resultsEl.style.display = 'block';
                resultsEl.innerHTML = `
                    <div class="robux-error-box" style="color:var(--text-sec);border-color:rgba(255,255,255,0.08);background:rgba(255,255,255,0.03)">
                        Nenhuma compra encontrada.<br>
                        <small>Certifique-se de que você já fez compras com Robux.</small>
                    </div>
                `;
            }
            robuxTrackerRunning = false;
            return;
        }

        robuxRenderResults(transactions, limiteds);
    }

    // ──────────────────────────────────────────
    //  DASHBOARD
    // ──────────────────────────────────────────

    function fmtNum(n) {
        if (n === null || n === undefined) return '—';
        if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
        if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
        return n.toLocaleString('en-US');
    }

    function renderPainel() {
        loadAccounts(function(accounts) {
            const total = accounts.length;

            // Aggregate totals
            let totalRobux   = 0;
            let totalResumo = 0;
            let totalRAP     = 0;
            let pendingCount = 0;

            accounts.forEach(function(acc) {
                const robux = parseInt(acc.robux || '0', 10) || 0;
                totalRobux += robux;

                if (acc.totalSpent !== null && acc.totalSpent !== undefined) {
                    totalResumo += acc.totalSpent;
                } else {
                    pendingCount++;
                }

                if (acc.totalRAP !== null && acc.totalRAP !== undefined) {
                    totalRAP += acc.totalRAP;
                }
            });

            // Update stat cards
            const elCookie  = document.getElementById('dashCookie');
            const elRobux   = document.getElementById('dashRobux');
            const elResumo = document.getElementById('dashResumo');
            const elRap     = document.getElementById('dashRap');
            const elNote    = document.getElementById('dashPendingNote');

            if (elCookie)  elCookie.textContent  = total;
            if (elRobux)   elRobux.textContent   = fmtNum(totalRobux);
            if (elResumo) elResumo.textContent  = fmtNum(totalResumo);
            if (elRap)     elRap.textContent      = fmtNum(totalRAP);

            if (elNote) {
                elNote.textContent = pendingCount > 0
                    ? `⏳ ${pendingCount} account(s) still being analyzed — partial values`
                    : '';
            }

            // Ranking by totalSpent
            const rankEl = document.getElementById('dashRanking');
            if (!rankEl) return;

            if (total === 0) {
                rankEl.innerHTML = `
                    <div class="dash-empty">
                        <i class="fas fa-chart-bar"></i>
                        Entre com um cookie para ver o ranking aqui.
                    </div>`;
                return;
            }

            const ranked = [...accounts]
                .filter(a => a.totalSpent !== null && a.totalSpent !== undefined)
                .sort((a, b) => (b.totalSpent || 0) - (a.totalSpent || 0));

            if (ranked.length === 0) {
                rankEl.innerHTML = `
                    <div class="dash-empty">
                        <i class="fas fa-hourglass-half"></i>
                        Analysis in progress...<br>Wait for account processing.
                    </div>`;
                return;
            }

            const rankColors = ['gold', 'silver', 'bronze'];

            rankEl.innerHTML = ranked.map(function(acc, i) {
                const rankCls  = rankColors[i] || '';
                const robux    = parseInt(acc.robux || '0', 10) || 0;
                const rap      = acc.totalRAP !== null && acc.totalRAP !== undefined
                    ? `<span class="rap-val">RAP ${fmtNum(acc.totalRAP)}</span>` : '';

                return `
                    <div class="dash-rank-item">
                        <div class="dash-rank-num ${rankCls}">#${i + 1}</div>
                        <img class="dash-rank-avatar"
                             src="${escHtml(acc.avatarUrl || '')}"
                             alt="${escHtml(acc.name)}"
                             onerror="this.style.display='none'">
                        <div class="dash-rank-info">
                            <div class="dash-rank-name">${escHtml(acc.name)}</div>
                            <div class="dash-rank-sub">
                                <span>${fmtNum(robux)} Robux</span>
                                ${rap}
                            </div>
                        </div>
                        <div class="dash-rank-spent">
                            ${fmtNum(acc.totalSpent)}
                            <small>Robux spent</small>
                        </div>
                    </div>`;
            }).join('');

            // Contas ainda não analisadas aparecem ao final
            const pending = accounts.filter(a => a.totalSpent === null || a.totalSpent === undefined);
            if (pending.length > 0) {
                rankEl.innerHTML += `
                    <div style="margin-top:8px; padding:8px 12px; background:rgba(245,158,11,0.07);
                                border:1px solid rgba(245,158,11,0.2); border-radius:9px;
                                font-size:11px; color:var(--warning); text-align:center;">
                        <i class="fas fa-spinner fa-spin" style="margin-right:5px;"></i>
                        ${pending.length} account(s) awaiting analysis
                    </div>`;
            }
        });
    }

    // Painel refresh button
    const dashAtualizarBtn = document.getElementById('dashAtualizarBtn');
    if (dashAtualizarBtn) {
        dashAtualizarBtn.addEventListener('click', renderPainel);
    }


    // ══════════════════════════════════════════
    //  AUTH TAB — TOTP 2FA
    // ══════════════════════════════════════════

    // ── Base32 decode ──
    function base32Decode(input) {
        const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        let bits = 0, value = 0;
        const output = [];
        const str = input.toUpperCase().replace(/=+$/, '').replace(/\s/g, '');
        for (let i = 0; i < str.length; i++) {
            const idx = alphabet.indexOf(str[i]);
            if (idx === -1) throw new Error('Caractere Base32 inválido: ' + str[i]);
            value = (value << 5) | idx;
            bits += 5;
            if (bits >= 8) {
                output.push((value >>> (bits - 8)) & 0xff);
                bits -= 8;
            }
        }
        return new Uint8Array(output);
    }

    // ── TOTP generate (uses SubtleCrypto) ──
    async function generateTOTP(secretB32, timeStep = 30, digits = 6) {
        const keyBytes = base32Decode(secretB32);
        const epoch = Math.floor(Date.now() / 1000);
        const counter = Math.floor(epoch / timeStep);

        const counterBuf = new ArrayBuffer(8);
        const view = new DataView(counterBuf);
        view.setUint32(4, counter, false);

        const cryptoKey = await crypto.subtle.importKey(
            'raw', keyBytes, { name: 'HMAC', hash: 'SHA-1' }, false, ['sign']
        );
        const sig = await crypto.subtle.sign('HMAC', cryptoKey, counterBuf);
        const hmac = new Uint8Array(sig);
        const offset = hmac[hmac.length - 1] & 0x0f;
        const code = (
            ((hmac[offset]     & 0x7f) << 24) |
            ((hmac[offset + 1] & 0xff) << 16) |
            ((hmac[offset + 2] & 0xff) <<  8) |
             (hmac[offset + 3] & 0xff)
        ) % Math.pow(10, digits);
        return String(code).padStart(digits, '0');
    }

    // ── Storage helpers ──
    function loadAuthKeys(cb) {
        chrome.storage.local.get(['beamseAuthKeys'], r => cb(r.beamseAuthKeys || []));
    }
    function saveAuthKeys(keys, cb) {
        chrome.storage.local.set({ beamseAuthKeys: keys }, cb || (() => {}));
    }

    // ── Live timer interval ──
    let authTimerInterval = null;

    function secondsRemaining() {
        return 30 - (Math.floor(Date.now() / 1000) % 30);
    }

    function ringDashOffset(secs) {
        const circumference = 2 * Math.PI * 14; // r=14
        return circumference * (1 - secs / 30);
    }

    // ── Render one card ──
    function buildAuthCard(entry, code) {
        const secs = secondsRemaining();
        const circumference = 2 * Math.PI * 14;
        const expiring = secs <= 7;
        const card = document.createElement('div');
        card.className = 'auth-card';
        card.dataset.id = entry.id;
        card.innerHTML = `
            <div class="auth-card-left">
                <div class="auth-card-icon"><i class="fas fa-lock"></i></div>
                <div>
                    <div class="auth-card-name">${escapeHtml(entry.name)}</div>
                    <div class="auth-card-code${expiring ? ' expiring' : ''}" data-code>${formatCode(code)}</div>
                </div>
            </div>
            <div class="auth-card-right">
                <svg class="auth-timer-ring" viewBox="0 0 34 34">
                    <circle class="ring-bg" cx="17" cy="17" r="14"/>
                    <circle class="ring-fg" cx="17" cy="17" r="14"
                        stroke-dasharray="${circumference.toFixed(2)}"
                        stroke-dashoffset="${ringDashOffset(secs).toFixed(2)}"/>
                </svg>
                <div class="auth-timer-secs" data-secs>${secs}s</div>
                <button class="auth-delete-btn" data-delete title="Remover">
                    <i class="fas fa-trash"></i>
                </button>
            </div>`;

        card.querySelector('[data-delete]').addEventListener('click', () => {
            deleteAuthKey(entry.id);
        });
        return card;
    }

    function formatCode(code) {
        return code.slice(0, 3) + ' ' + code.slice(3);
    }

    function escapeHtml(str) {
        return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    // ── Render all cards ──
    async function renderAuthList() {
        loadAuthKeys(async (keys) => {
            const list = document.getElementById('authList');
            const countBadge = document.getElementById('authCount');
            if (!list) return;
            list.innerHTML = '';
            if (countBadge) countBadge.textContent = keys.length;

            if (keys.length === 0) {
                list.innerHTML = `<div class="auth-empty">
                    <i class="fas fa-shield-alt"></i>
                    Nenhum autenticador ainda.<br>Toque em <strong>+</strong> para adicionar um.
                </div>`;
                return;
            }

            for (const entry of keys) {
                let code = '------';
                try { code = await generateTOTP(entry.key); } catch (_) {}
                list.appendChild(buildAuthCard(entry, code));
            }
        });
    }

    // ── Live tick — update codes + rings every second ──
    function startAuthTimer() {
        if (authTimerInterval) clearInterval(authTimerInterval);
        authTimerInterval = setInterval(async () => {
            const secs = secondsRemaining();
            const circumference = 2 * Math.PI * 14;
            const expiring = secs <= 7;

            // Update rings & timers
            document.querySelectorAll('#authList .auth-card').forEach(card => {
                const ringFg = card.querySelector('.ring-fg');
                const secsEl = card.querySelector('[data-secs]');
                if (ringFg) ringFg.setAttribute('stroke-dashoffset', ringDashOffset(secs).toFixed(2));
                if (secsEl) secsEl.textContent = secs + 's';
            });

            // On each new 30s window, refresh codes
            if (secs === 30) {
                loadAuthKeys(async (keys) => {
                    const cards = document.querySelectorAll('#authList .auth-card');
                    for (const card of cards) {
                        const id = card.dataset.id;
                        const entry = keys.find(k => k.id === id);
                        if (!entry) continue;
                        const codeEl = card.querySelector('[data-code]');
                        try {
                            const code = await generateTOTP(entry.key);
                            if (codeEl) codeEl.textContent = formatCode(code);
                        } catch (_) {}
                    }
                });
            }

            // Tint expiring codes
            document.querySelectorAll('#authList [data-code]').forEach(el => {
                if (expiring) el.classList.add('expiring');
                else el.classList.remove('expiring');
            });
        }, 1000);
    }

    function stopAuthTimer() {
        if (authTimerInterval) { clearInterval(authTimerInterval); authTimerInterval = null; }
    }

    // ── Excluir ──
    function deleteAuthKey(id) {
        loadAuthKeys(keys => {
            const updated = keys.filter(k => k.id !== id);
            saveAuthKeys(updated, () => renderAuthList());
        });
    }

    // ── Modal logic ──
    const authModalOverlay = document.getElementById('authModalOverlay');
    const authModalCancel  = document.getElementById('authModalCancel');
    const authModalSave    = document.getElementById('authModalSave');
    const authInputName    = document.getElementById('authInputName');
    const authInputKey     = document.getElementById('authInputKey');
    const authModalError   = document.getElementById('authModalError');
    const authAddBtn       = document.getElementById('authAddBtn');

    function openAuthModal() {
        authInputName.value = '';
        authInputKey.value  = '';
        authModalError.style.display = 'none';
        authModalOverlay.classList.add('open');
        setTimeout(() => authInputName.focus(), 60);
    }
    function closeAuthModal() {
        authModalOverlay.classList.remove('open');
    }
    function showAuthModalError(msg) {
        authModalError.textContent = msg;
        authModalError.style.display = 'block';
    }

    if (authAddBtn) authAddBtn.addEventListener('click', openAuthModal);
    if (authModalCancel) authModalCancel.addEventListener('click', closeAuthModal);
    authModalOverlay && authModalOverlay.addEventListener('click', e => {
        if (e.target === authModalOverlay) closeAuthModal();
    });

    if (authModalSave) {
        authModalSave.addEventListener('click', async () => {
            const name = authInputName.value.trim();
            const key  = authInputKey.value.trim().replace(/\s/g, '');
            if (!name) { showAuthModalError('Digite um nome para a conta.'); return; }
            if (!key)  { showAuthModalError('Digite uma chave secreta.'); return; }

            // Validate key by attempting TOTP
            try {
                await generateTOTP(key);
            } catch (e) {
                showAuthModalError('Chave secreta inválida. Use uma chave Base32 válida.');
                return;
            }

            const id = 'auth_' + Date.now() + '_' + Math.random().toString(36).slice(2);
            loadAuthKeys(keys => {
                keys.push({ id, name, key });
                saveAuthKeys(keys, () => {
                    closeAuthModal();
                    renderAuthList();
                });
            });
        });
    }

    // Hook into switchTab to start/stop timer
    const _originalSwitchTab = switchTab;
    // Patch tab switching for auth
    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tab = btn.getAttribute('data-tab');
            if (tab === 'auth') {
                renderAuthList();
                startAuthTimer();
            } else {
                stopAuthTimer();
            }
        });
    });


    // ── INIT ──
    showLogin();
});

    try { renderRecentAccounts(); } catch (_) {}
