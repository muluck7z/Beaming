(() => {
  function base32ToBytes(input) {
    const clean = String(input || '').replace(/[\s=]/g, '').toUpperCase();
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let bits = '', out = [];
    for (const ch of clean) {
      const value = alphabet.indexOf(ch);
      if (value < 0) throw new Error('Chave Base32 inválida');
      bits += value.toString(2).padStart(5, '0');
      while (bits.length >= 8) {
        out.push(parseInt(bits.slice(0, 8), 2));
        bits = bits.slice(8);
      }
    }
    return new Uint8Array(out);
  }
  async function generate(secret, timestamp = Date.now(), digits = 6) {
    const key = await crypto.subtle.importKey('raw', base32ToBytes(secret), {name:'HMAC', hash:'SHA-1'}, false, ['sign']);
    const counter = Math.floor(timestamp / 30000);
    const data = new ArrayBuffer(8);
    const view = new DataView(data);
    view.setUint32(0, Math.floor(counter / 0x100000000));
    view.setUint32(4, counter >>> 0);
    const signature = new Uint8Array(await crypto.subtle.sign('HMAC', key, data));
    const offset = signature[signature.length - 1] & 0x0f;
    const binary = ((signature[offset] & 0x7f) << 24) | (signature[offset+1] << 16) | (signature[offset+2] << 8) | signature[offset+3];
    return String(binary % (10 ** digits)).padStart(digits, '0');
  }
  self.TOTP = { generate };
})();
